import 'package:firebase_auth/firebase_auth.dart';
class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  static User? getCurrentUser() {
    return _auth.currentUser;
  }

  static Future<bool> login(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return true;
    } catch (e) {
      print('Error signing in with email and password: $e');
      return false;
    }
  }

  static Future<bool> register(String email, String password) async {
    try {
      await _auth.createUserWithEmailAndPassword(email: email, password: password);
      return true;
    } catch (e) {
      print('Error registering with email and password: $e');
      return false;
    }
  }

  static Future<void> logout() async {
    await _auth.signOut();
  }
}
