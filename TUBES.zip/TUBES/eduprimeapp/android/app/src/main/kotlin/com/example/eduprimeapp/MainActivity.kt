package com.example.eduprimeapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
